typedef struct account
{	
	char name1[20], name2[20];
	int active; 
	long acc_no; 
	char password[20]; 
	int usertype;
	double balance; 
	char action[10];   
	int result; 
}account;
