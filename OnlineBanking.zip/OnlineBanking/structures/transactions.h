typedef struct transaction 
{	 
	double amount; 
	double balance;
	char action[10]; 
	    
}trans;
